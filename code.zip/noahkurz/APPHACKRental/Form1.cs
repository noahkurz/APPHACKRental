﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace APPHACKRental
{
    public partial class Rental_Price : Form
    {
        
        public Rental_Price()
        {
            InitializeComponent();
            this.property_type_combobox.SelectedIndex = 0;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var queryaddress = generateWebQuery();

            googleMap.Navigate(queryaddress.ToString());

            var averageRentalPrice = getAverageRentalPrice();

            MessageBox.Show(averageRentalPrice);
        }

        private StringBuilder generateWebQuery()
        {
            var queryaddress = new StringBuilder("http://google.com/maps?q=");

            if (!string.IsNullOrEmpty(city_textbox.Text))
            {
                queryaddress.Append(street_textbox.Text + "," + "+");
            }
            else
            {
                queryaddress.Append(street_textbox.Text);
            }

            if (!string.IsNullOrEmpty(state_textbox.Text))
            {
                queryaddress.Append(city_textbox.Text + "," + "+");
            }
            else
            {
                queryaddress.Append(city_textbox.Text);
            }

            if (!string.IsNullOrEmpty(zip_textbox.Text))
            {
                queryaddress.Append(state_textbox.Text + "," + "+");
            }
            else
            {
                queryaddress.Append(state_textbox.Text);
            }

            queryaddress.Append(zip_textbox.Text);

            return queryaddress;

        }

        private string getAverageRentalPrice()
        {
            var sqFootage = sqFootage_textbox.Text;
            var bathrooms = bathroom_textbox.Text;
            var bedrooms = beds_textbox.Text;
            var address = street_textbox.Text.Replace(" ", "%20") + "%20" + city_textbox.Text + "%20" + state_textbox.Text;
            var propertyType = property_type_combobox.Text.Replace(" ", "%20");

            var client = new RestClient("https://realty-mole-property-api.p.rapidapi.com/rentalPrice?compCount=5&squareFootage=" + sqFootage + "&bathrooms=+" + bathrooms + "&address=" + address + "&bedrooms=" + bedrooms + "&propertyType=" + propertyType);
            var request = new RestRequest(Method.GET);

            request.AddHeader("x-rapidapi-key", "933810526emshe0db0ab74036398p1a09c9jsnda3a3baba65b");
            request.AddHeader("x-rapidapi-host", "realty-mole-property-api.p.rapidapi.com");

            IRestResponse response = client.Execute(request);
            var rentalData = JObject.Parse(response.Content);

            return rentalData.GetValue("rent").ToString();
        }

    }
}
