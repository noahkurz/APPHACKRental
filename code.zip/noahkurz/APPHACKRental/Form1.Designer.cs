﻿namespace APPHACKRental
{
    partial class Rental_Price
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.bedrooms = new System.Windows.Forms.Label();
            this.beds_textbox = new System.Windows.Forms.TextBox();
            this.baths = new System.Windows.Forms.Label();
            this.bathroom_textbox = new System.Windows.Forms.TextBox();
            this.sqFoot = new System.Windows.Forms.Label();
            this.sqFootage_textbox = new System.Windows.Forms.TextBox();
            this.zip_label = new System.Windows.Forms.Label();
            this.state_label = new System.Windows.Forms.Label();
            this.city_label = new System.Windows.Forms.Label();
            this.street_label = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.zip_textbox = new System.Windows.Forms.TextBox();
            this.state_textbox = new System.Windows.Forms.TextBox();
            this.city_textbox = new System.Windows.Forms.TextBox();
            this.street_textbox = new System.Windows.Forms.TextBox();
            this.googleMap = new Microsoft.Toolkit.Forms.UI.Controls.WebViewCompatible();
            this.label1 = new System.Windows.Forms.Label();
            this.property_type_combobox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.property_type_combobox);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.bedrooms);
            this.splitContainer1.Panel1.Controls.Add(this.beds_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.baths);
            this.splitContainer1.Panel1.Controls.Add(this.bathroom_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.sqFoot);
            this.splitContainer1.Panel1.Controls.Add(this.sqFootage_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.zip_label);
            this.splitContainer1.Panel1.Controls.Add(this.state_label);
            this.splitContainer1.Panel1.Controls.Add(this.city_label);
            this.splitContainer1.Panel1.Controls.Add(this.street_label);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel1.Controls.Add(this.zip_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.state_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.city_textbox);
            this.splitContainer1.Panel1.Controls.Add(this.street_textbox);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.googleMap);
            this.splitContainer1.Size = new System.Drawing.Size(1057, 688);
            this.splitContainer1.SplitterDistance = 212;
            this.splitContainer1.TabIndex = 0;
            // 
            // bedrooms
            // 
            this.bedrooms.AutoSize = true;
            this.bedrooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bedrooms.Location = new System.Drawing.Point(12, 221);
            this.bedrooms.Name = "bedrooms";
            this.bedrooms.Size = new System.Drawing.Size(117, 25);
            this.bedrooms.TabIndex = 14;
            this.bedrooms.Text = "Bedrooms";
            // 
            // beds_textbox
            // 
            this.beds_textbox.Location = new System.Drawing.Point(17, 263);
            this.beds_textbox.Name = "beds_textbox";
            this.beds_textbox.Size = new System.Drawing.Size(161, 20);
            this.beds_textbox.TabIndex = 3;
            this.beds_textbox.Text = "4";
            // 
            // baths
            // 
            this.baths.AutoSize = true;
            this.baths.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baths.Location = new System.Drawing.Point(12, 143);
            this.baths.Name = "baths";
            this.baths.Size = new System.Drawing.Size(124, 25);
            this.baths.TabIndex = 12;
            this.baths.Text = "Bathrooms";
            // 
            // bathroom_textbox
            // 
            this.bathroom_textbox.Location = new System.Drawing.Point(17, 184);
            this.bathroom_textbox.Name = "bathroom_textbox";
            this.bathroom_textbox.Size = new System.Drawing.Size(161, 20);
            this.bathroom_textbox.TabIndex = 2;
            this.bathroom_textbox.Text = "2";
            // 
            // sqFoot
            // 
            this.sqFoot.AutoSize = true;
            this.sqFoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqFoot.Location = new System.Drawing.Point(12, 70);
            this.sqFoot.Name = "sqFoot";
            this.sqFoot.Size = new System.Drawing.Size(180, 25);
            this.sqFoot.TabIndex = 10;
            this.sqFoot.Text = "Square Footage";
            // 
            // sqFootage_textbox
            // 
            this.sqFootage_textbox.Location = new System.Drawing.Point(17, 110);
            this.sqFootage_textbox.Name = "sqFootage_textbox";
            this.sqFootage_textbox.Size = new System.Drawing.Size(161, 20);
            this.sqFootage_textbox.TabIndex = 1;
            this.sqFootage_textbox.Text = "1600";
            // 
            // zip_label
            // 
            this.zip_label.AutoSize = true;
            this.zip_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zip_label.Location = new System.Drawing.Point(12, 548);
            this.zip_label.Name = "zip_label";
            this.zip_label.Size = new System.Drawing.Size(107, 25);
            this.zip_label.TabIndex = 8;
            this.zip_label.Text = "Zip Code";
            // 
            // state_label
            // 
            this.state_label.AutoSize = true;
            this.state_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.state_label.Location = new System.Drawing.Point(12, 467);
            this.state_label.Name = "state_label";
            this.state_label.Size = new System.Drawing.Size(67, 25);
            this.state_label.TabIndex = 7;
            this.state_label.Text = "State";
            // 
            // city_label
            // 
            this.city_label.AutoSize = true;
            this.city_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city_label.Location = new System.Drawing.Point(12, 384);
            this.city_label.Name = "city_label";
            this.city_label.Size = new System.Drawing.Size(53, 25);
            this.city_label.TabIndex = 6;
            this.city_label.Text = "City";
            // 
            // street_label
            // 
            this.street_label.AutoSize = true;
            this.street_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.street_label.Location = new System.Drawing.Point(12, 299);
            this.street_label.Name = "street_label";
            this.street_label.Size = new System.Drawing.Size(75, 25);
            this.street_label.TabIndex = 5;
            this.street_label.Text = "Street";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(76, 646);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(116, 30);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // zip_textbox
            // 
            this.zip_textbox.Location = new System.Drawing.Point(17, 596);
            this.zip_textbox.Name = "zip_textbox";
            this.zip_textbox.Size = new System.Drawing.Size(161, 20);
            this.zip_textbox.TabIndex = 7;
            this.zip_textbox.Text = "53090";
            // 
            // state_textbox
            // 
            this.state_textbox.Location = new System.Drawing.Point(17, 504);
            this.state_textbox.Name = "state_textbox";
            this.state_textbox.Size = new System.Drawing.Size(161, 20);
            this.state_textbox.TabIndex = 6;
            this.state_textbox.Text = "TX";
            // 
            // city_textbox
            // 
            this.city_textbox.Location = new System.Drawing.Point(17, 429);
            this.city_textbox.Name = "city_textbox";
            this.city_textbox.Size = new System.Drawing.Size(161, 20);
            this.city_textbox.TabIndex = 5;
            this.city_textbox.Text = "San Antonio";
            // 
            // street_textbox
            // 
            this.street_textbox.Location = new System.Drawing.Point(17, 343);
            this.street_textbox.Name = "street_textbox";
            this.street_textbox.Size = new System.Drawing.Size(161, 20);
            this.street_textbox.TabIndex = 4;
            this.street_textbox.Text = "5500 Grand Lake Drive";
            // 
            // googleMap
            // 
            this.googleMap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.googleMap.Location = new System.Drawing.Point(0, 0);
            this.googleMap.Name = "googleMap";
            this.googleMap.Size = new System.Drawing.Size(841, 688);
            this.googleMap.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 25);
            this.label1.TabIndex = 15;
            this.label1.Text = "Property Type";
            // 
            // property_type_combobox
            // 
            this.property_type_combobox.AllowDrop = true;
            this.property_type_combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.property_type_combobox.FormattingEnabled = true;
            this.property_type_combobox.Items.AddRange(new object[] {
            "Apartment",
            "Single Family",
            "Townhouse",
            "Condo",
            "Duplex-Triplex"});
            this.property_type_combobox.Location = new System.Drawing.Point(17, 46);
            this.property_type_combobox.Name = "property_type_combobox";
            this.property_type_combobox.Size = new System.Drawing.Size(155, 21);
            this.property_type_combobox.TabIndex = 0;
            // 
            // Rental_Price
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 688);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Rental_Price";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Average Rent";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox zip_textbox;
        private System.Windows.Forms.TextBox state_textbox;
        private System.Windows.Forms.TextBox city_textbox;
        private System.Windows.Forms.TextBox street_textbox;
        private Microsoft.Toolkit.Forms.UI.Controls.WebViewCompatible googleMap;
        private System.Windows.Forms.Label zip_label;
        private System.Windows.Forms.Label state_label;
        private System.Windows.Forms.Label city_label;
        private System.Windows.Forms.Label street_label;
        private System.Windows.Forms.Label bedrooms;
        private System.Windows.Forms.TextBox beds_textbox;
        private System.Windows.Forms.Label baths;
        private System.Windows.Forms.TextBox bathroom_textbox;
        private System.Windows.Forms.Label sqFoot;
        private System.Windows.Forms.TextBox sqFootage_textbox;
        private System.Windows.Forms.ComboBox property_type_combobox;
        private System.Windows.Forms.Label label1;
    }
}

